/*
SQLyog Community v11.1 (64 bit)
MySQL - 5.6.24-log : Database - mas_report
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`mas_report` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `mas_report`;

/*Table structure for table `t_menu` */

DROP TABLE IF EXISTS `t_menu`;

CREATE TABLE `t_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_id` int(11) DEFAULT NULL,
  `code` varchar(30) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `seq` int(11) DEFAULT '0',
  `uri` varchar(50) DEFAULT NULL,
  `parent_id` int(11) DEFAULT '0' COMMENT '父级菜单',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8 COMMENT='菜单表';

/*Data for the table `t_menu` */

insert  into `t_menu`(`id`,`type_id`,`code`,`name`,`icon`,`seq`,`uri`,`parent_id`) values (1,2,'role','角色管理',NULL,2,'role/list',36),(2,2,'user','用户管理',NULL,3,'user/list',36),(5,2,'accountRechargeSum','账号充值汇总',NULL,11,'account/accountRechargeSum',39),(6,2,'accountRechargeDetail','账号充值明细',NULL,7,'account/accountRechargeDetail',39),(7,2,'accountConsumeSum','账号消费汇总',NULL,13,'account/accountConsumeSum',39),(8,2,'accountConsumeDetail','账号消费明细',NULL,10,'account/accountConsumeDetail',39),(9,2,'accountStartupDetail','账号启动明细',NULL,15,'account/accountStartupDetail',37),(10,2,'rechargeCollect','充值渠道汇总',NULL,16,'pay/rechargeCollect',39),(11,2,'rechargeAlleywayDetail','充值渠道明细',NULL,17,'pay/rechargeAlleywayDetail',39),(12,2,'productConsumeCollect','厂商消耗汇总',NULL,18,'pay/productConsumeCollect',39),(13,2,'productConsumeDetail','厂商消耗明细',NULL,19,'pay/productConsumeDetail',39),(14,2,'masuser','平台注册用户',NULL,5,'masuser/list',37),(15,2,'clientuser','平台激活设备',NULL,4,'clientuser/list',37),(16,2,'activatelog','平台启动日志',NULL,1,'activateLog/list',37),(17,2,'ravedebaclelog','平台崩溃日志',NULL,1,'ravedebaclelog/list',37),(18,2,'appsearchlog','应用搜索日志',NULL,0,'appsearchlog/group',37),(19,2,'machine','预装设备激活统计',NULL,8,'machine/list',37),(20,2,'appdownload','应用下载统计',NULL,3,'appdownload/list',38),(21,2,'musicdownload','铃声下载统计',NULL,7,'musicdownload/list',38),(22,2,'imagedownload','图片下载统计',NULL,6,'imagedownload/list',38),(23,2,'menu','菜单管理',NULL,2,'menu/list',36),(36,1,'system','系统管理','n2.png',1,'system',0),(37,1,'platform','平台管理','n3.png',2,'platform',0),(38,1,'zappdownload','应用下载管理','n1.png',2,'zappdownload',0),(39,1,'account','财报管理','n4.png',3,'account',0),(40,2,'selfappdownload','自营下载统计',NULL,0,'appdownload/self',38),(41,2,'appdistribute','应用分发统计',NULL,0,'appdistribute/list',38);

/*Table structure for table `t_menu_type` */

DROP TABLE IF EXISTS `t_menu_type`;

CREATE TABLE `t_menu_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `seq` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='菜单类型表';

/*Data for the table `t_menu_type` */

insert  into `t_menu_type`(`id`,`name`,`icon`,`seq`) values (1,'一级菜单',NULL,1),(2,'二级菜单','',2),(3,'三级菜单','',3);

/*Table structure for table `t_operation` */

DROP TABLE IF EXISTS `t_operation`;

CREATE TABLE `t_operation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  `code` varchar(30) DEFAULT NULL,
  `type_id` int(11) DEFAULT NULL,
  `description` varchar(50) DEFAULT NULL,
  `seq` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='操作权限表';

/*Data for the table `t_operation` */

/*Table structure for table `t_operation_type` */

DROP TABLE IF EXISTS `t_operation_type`;

CREATE TABLE `t_operation_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  `seq` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='操作类型表';

/*Data for the table `t_operation_type` */

/*Table structure for table `t_role` */

DROP TABLE IF EXISTS `t_role`;

CREATE TABLE `t_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  `description` varchar(50) DEFAULT NULL,
  `seq` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COMMENT='角色表';

/*Data for the table `t_role` */

insert  into `t_role`(`id`,`name`,`description`,`seq`) values (1,'系统管理员','系统管理员',1),(2,'系统操作员','系统操作员',2),(3,'渠道商管理员','渠道商管理员',3),(4,'CP厂商管理员','CP厂商管理员',7),(5,'APP应用管理员','APP应用管理员',4),(17,'普通用户','查看数据用户',9);

/*Table structure for table `t_role_menu` */

DROP TABLE IF EXISTS `t_role_menu`;

CREATE TABLE `t_role_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) DEFAULT NULL,
  `menu_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=200 DEFAULT CHARSET=utf8 COMMENT='角色-菜单表';

/*Data for the table `t_role_menu` */

insert  into `t_role_menu`(`id`,`role_id`,`menu_id`) values (1,1,1),(2,1,2),(12,4,12),(13,4,13),(30,2,8),(31,2,5),(32,2,7),(33,2,10),(34,2,11),(35,2,12),(36,2,13),(40,2,6),(41,3,10),(42,3,11),(43,5,12),(44,5,13),(45,3,8),(46,3,5),(64,5,17),(65,5,15),(66,5,2),(96,2,19),(97,2,18),(98,2,17),(99,2,15),(100,2,14),(101,2,16),(103,2,2),(110,1,23),(111,1,14),(112,1,15),(113,1,16),(114,1,38),(115,1,36),(116,1,37),(118,1,22),(119,1,21),(120,1,20),(121,1,19),(122,1,18),(123,1,17),(143,1,39),(144,1,6),(145,1,8),(146,1,5),(147,1,7),(153,5,39),(155,1,10),(156,1,11),(157,1,12),(158,1,13),(162,2,38),(163,2,20),(164,2,21),(165,2,22),(166,2,36),(167,2,37),(168,2,39),(169,2,9),(195,1,41),(196,1,40),(197,1,9),(198,2,41),(199,2,40);

/*Table structure for table `t_role_operation` */

DROP TABLE IF EXISTS `t_role_operation`;

CREATE TABLE `t_role_operation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) DEFAULT NULL,
  `operation_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色-操作权限表';

/*Data for the table `t_role_operation` */

/*Table structure for table `t_user` */

DROP TABLE IF EXISTS `t_user`;

CREATE TABLE `t_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) DEFAULT NULL,
  `password` varchar(64) DEFAULT NULL,
  `activable` int(11) DEFAULT NULL,
  `mobile` varchar(15) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `insert_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='用户表';

/*Data for the table `t_user` */

insert  into `t_user`(`id`,`name`,`password`,`activable`,`mobile`,`email`,`insert_date`) values (1,'admin','A66ABB5684C45962D887564F08346E8D',1,'','','2011-11-12');

/*Table structure for table `t_user_role` */

DROP TABLE IF EXISTS `t_user_role`;

CREATE TABLE `t_user_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='用户-角色表';

/*Data for the table `t_user_role` */

insert  into `t_user_role`(`id`,`user_id`,`role_id`) values (1,1,1);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
